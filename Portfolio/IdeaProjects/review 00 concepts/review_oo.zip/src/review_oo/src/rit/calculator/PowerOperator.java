package review_oo.src.rit.calculator;

public class PowerOperator extends BinaryOperator{
}
