package review_oo.src.rit.calculator;


public class BinaryOperation{
    private double NaN;
    private double Na;

    public double getResult(){
        return NaN;
    }
}
